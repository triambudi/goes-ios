# Gowes iOS (cyclocomputer untuk iPhone 5s, iOS 12.5.7)

Fitur: kecepatan, jarak, waktu, rata-rata, maks, detak jantung (BLE 0x180D), lap,
simpan GPX saat SELESAI (folder Documents app, buka lewat Filza atau ideviceinstaller/ifuse).

## Build tanpa Mac
1. Buat repo GitHub baru, upload isi folder ini (branch main).
2. Tab Actions -> "Build IPA" -> tunggu hijau (atau Run workflow).
3. Unduh artifact `Gowes-ipa`, ekstrak jadi `Gowes.ipa`.

## Pasang di iPhone 5s (setelah checkra1n + AppSync Unified)
Dari Pop!_OS:
    sudo apt install ideviceinstaller libimobiledevice-utils
    ideviceinstaller -i Gowes.ipa
Atau salin IPA ke iPhone, buka dengan Filza -> Install.

## Catatan
- Izinkan lokasi "Saat Digunakan", dan Bluetooth saat diminta.
- HR band harus menyiarkan HR (seperti yang dipakai di versi Android).
- Kode belum pernah dikompilasi; kalau build gagal, kirim log error dari tab Actions.
