import UIKit

final class MainViewController: UIViewController, RideEngineDelegate {
    private let engine = RideEngine()

    private let gpsLabel = UILabel()
    private let hrStatusLabel = UILabel()
    private let speedLabel = UILabel()
    private let distVal = UILabel()
    private let timeVal = UILabel()
    private let avgVal = UILabel()
    private let maxVal = UILabel()
    private let hrVal = UILabel()
    private let lapLabel = UILabel()
    private let startBtn = UIButton(type: .system)
    private let lapBtn = UIButton(type: .system)
    private let stopBtn = UIButton(type: .system)

    override var preferredStatusBarStyle: UIStatusBarStyle { return .lightContent }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black

        for l in [gpsLabel, hrStatusLabel] {
            l.font = .systemFont(ofSize: 12, weight: .medium)
            l.textColor = .lightGray
        }
        hrStatusLabel.textAlignment = .right
        let topRow = UIStackView(arrangedSubviews: [gpsLabel, hrStatusLabel])
        topRow.distribution = .fillEqually

        speedLabel.font = .monospacedDigitSystemFont(ofSize: 110, weight: .bold)
        speedLabel.textColor = .white
        speedLabel.textAlignment = .center
        speedLabel.adjustsFontSizeToFitWidth = true
        speedLabel.minimumScaleFactor = 0.5
        speedLabel.text = "0.0"
        speedLabel.setContentHuggingPriority(.defaultLow, for: .vertical)

        let unit = UILabel()
        unit.text = "km/h"
        unit.font = .systemFont(ofSize: 16, weight: .medium)
        unit.textColor = .lightGray
        unit.textAlignment = .center

        let row1 = UIStackView(arrangedSubviews: [stat("JARAK km", distVal), stat("WAKTU", timeVal)])
        let row2 = UIStackView(arrangedSubviews: [stat("RATA-RATA km/h", avgVal), stat("MAKS km/h", maxVal)])
        for r in [row1, row2] { r.distribution = .fillEqually }
        let hrRow = stat("DETAK JANTUNG bpm", hrVal, color: UIColor(red: 1, green: 0.35, blue: 0.4, alpha: 1))

        lapLabel.font = .systemFont(ofSize: 13)
        lapLabel.textColor = .lightGray
        lapLabel.textAlignment = .center

        style(startBtn, "MULAI", UIColor(red: 0.1, green: 0.6, blue: 0.3, alpha: 1), #selector(startTapped))
        style(lapBtn, "LAP", UIColor(red: 0.2, green: 0.4, blue: 0.8, alpha: 1), #selector(lapTapped))
        style(stopBtn, "SELESAI", UIColor(red: 0.7, green: 0.2, blue: 0.2, alpha: 1), #selector(stopTapped))
        let btns = UIStackView(arrangedSubviews: [startBtn, lapBtn, stopBtn])
        btns.distribution = .fillEqually
        btns.spacing = 8

        let main = UIStackView(arrangedSubviews: [topRow, speedLabel, unit, row1, row2, hrRow, lapLabel, btns])
        main.axis = .vertical
        main.spacing = 10
        main.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(main)
        let g = view.safeAreaLayoutGuide
        NSLayoutConstraint.activate([
            main.leadingAnchor.constraint(equalTo: g.leadingAnchor, constant: 12),
            main.trailingAnchor.constraint(equalTo: g.trailingAnchor, constant: -12),
            main.topAnchor.constraint(equalTo: g.topAnchor, constant: 8),
            main.bottomAnchor.constraint(equalTo: g.bottomAnchor, constant: -12),
            btns.heightAnchor.constraint(equalToConstant: 52)
        ])

        engine.delegate = self
        engine.begin()
        engineDidUpdate(engine)
    }

    private func stat(_ title: String, _ value: UILabel, color: UIColor = .white) -> UIStackView {
        let t = UILabel()
        t.text = title
        t.font = .systemFont(ofSize: 11, weight: .medium)
        t.textColor = .lightGray
        t.textAlignment = .center
        value.font = .monospacedDigitSystemFont(ofSize: 30, weight: .semibold)
        value.textColor = color
        value.textAlignment = .center
        value.adjustsFontSizeToFitWidth = true
        value.minimumScaleFactor = 0.6
        value.text = "0"
        let s = UIStackView(arrangedSubviews: [t, value])
        s.axis = .vertical
        s.spacing = 2
        return s
    }

    private func style(_ b: UIButton, _ title: String, _ color: UIColor, _ action: Selector) {
        b.setTitle(title, for: .normal)
        b.setTitleColor(.white, for: .normal)
        b.titleLabel?.font = .systemFont(ofSize: 16, weight: .bold)
        b.backgroundColor = color
        b.layer.cornerRadius = 10
        b.addTarget(self, action: action, for: .touchUpInside)
    }

    @objc private func startTapped() { engine.startPause() }
    @objc private func lapTapped() { engine.lap() }

    @objc private func stopTapped() {
        guard engine.state != .idle else { return }
        let url = engine.finish()
        let msg = url != nil ? "Tersimpan: \(url!.lastPathComponent)" : "Belum ada data GPS untuk disimpan."
        let a = UIAlertController(title: "Selesai", message: msg, preferredStyle: .alert)
        a.addAction(UIAlertAction(title: "OK", style: .default))
        present(a, animated: true)
    }

    func engineDidUpdate(_ e: RideEngine) {
        gpsLabel.text = e.gpsOK ? "GPS: OK" : "GPS: mencari..."
        hrStatusLabel.text = e.hrStatus
        speedLabel.text = String(format: "%.1f", e.speedKmh)
        distVal.text = String(format: "%.2f", e.distanceM / 1000)
        timeVal.text = RideEngine.format(e.elapsed)
        avgVal.text = String(format: "%.1f", e.avgKmh)
        maxVal.text = String(format: "%.1f", e.maxSpeedKmh)
        hrVal.text = e.heartRate > 0 ? "\(e.heartRate)" : "--"
        lapLabel.text = e.lapText
        switch e.state {
        case .idle: startBtn.setTitle("MULAI", for: .normal)
        case .running: startBtn.setTitle("JEDA", for: .normal)
        case .paused: startBtn.setTitle("LANJUT", for: .normal)
        }
    }
}
