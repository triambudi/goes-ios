import Foundation
import CoreLocation
import CoreBluetooth

protocol RideEngineDelegate: AnyObject {
    func engineDidUpdate(_ engine: RideEngine)
}

final class RideEngine: NSObject, CLLocationManagerDelegate, CBCentralManagerDelegate, CBPeripheralDelegate {
    enum State { case idle, running, paused }

    weak var delegate: RideEngineDelegate?
    private(set) var state: State = .idle
    private(set) var speedKmh: Double = 0
    private(set) var maxSpeedKmh: Double = 0
    private(set) var distanceM: Double = 0
    private(set) var elapsed: TimeInterval = 0
    private(set) var heartRate: Int = 0
    private(set) var gpsOK = false
    private(set) var hrStatus = "HR: mencari..."
    private(set) var lapText = ""

    var avgKmh: Double { elapsed > 0 ? (distanceM / 1000) / (elapsed / 3600) : 0 }

    private var lapCount = 0
    private var lapStartDist: Double = 0
    private var lapStartTime: TimeInterval = 0
    private var lastLoc: CLLocation?
    private var lastTick: Date?
    private var points: [(loc: CLLocation, hr: Int)] = []
    private var timer: Timer?

    private let lm = CLLocationManager()
    private var central: CBCentralManager!
    private var hrPeripheral: CBPeripheral?
    private let hrService = CBUUID(string: "180D")
    private let hrChar = CBUUID(string: "2A37")

    override init() {
        super.init()
        lm.delegate = self
        lm.desiredAccuracy = kCLLocationAccuracyBestForNavigation
        lm.activityType = .fitness
        lm.distanceFilter = kCLDistanceFilterNone
        lm.allowsBackgroundLocationUpdates = true
        lm.pausesLocationUpdatesAutomatically = false
        central = CBCentralManager(delegate: self, queue: nil)
    }

    func begin() {
        lm.requestWhenInUseAuthorization()
        lm.startUpdatingLocation()
        timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { [weak self] _ in self?.tick() }
    }

    // MARK: - Kontrol

    func startPause() {
        switch state {
        case .idle:
            resetRide()
            state = .running
            lastTick = Date()
        case .running:
            state = .paused
        case .paused:
            state = .running
            lastTick = Date()
        }
        delegate?.engineDidUpdate(self)
    }

    func lap() {
        guard state != .idle else { return }
        lapCount += 1
        let d = (distanceM - lapStartDist) / 1000
        let t = elapsed - lapStartTime
        lapText = String(format: "Lap %d: %.2f km  %@", lapCount, d, RideEngine.format(t))
        lapStartDist = distanceM
        lapStartTime = elapsed
        delegate?.engineDidUpdate(self)
    }

    /// Selesai: simpan GPX, kembali ke idle. Mengembalikan URL file bila ada titik.
    func finish() -> URL? {
        let url = saveGPX()
        state = .idle
        delegate?.engineDidUpdate(self)
        return url
    }

    private func resetRide() {
        distanceM = 0; elapsed = 0; maxSpeedKmh = 0
        lapCount = 0; lapStartDist = 0; lapStartTime = 0; lapText = ""
        points.removeAll()
    }

    private func tick() {
        if state == .running, let t = lastTick { elapsed += Date().timeIntervalSince(t) }
        lastTick = Date()
        delegate?.engineDidUpdate(self)
    }

    // MARK: - GPS

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        for l in locations {
            guard l.horizontalAccuracy >= 0, l.horizontalAccuracy < 30 else { gpsOK = false; continue }
            gpsOK = true
            var v = l.speed >= 0 ? l.speed * 3.6 : 0
            if v < 1.5 { v = 0 }
            speedKmh = v
            if state == .running {
                if let p = lastLoc {
                    let d = l.distance(from: p)
                    if d > 2 { distanceM += d }
                }
                maxSpeedKmh = max(maxSpeedKmh, v)
                points.append((l, heartRate))
            }
            lastLoc = l
        }
        delegate?.engineDidUpdate(self)
    }

    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        gpsOK = false
        delegate?.engineDidUpdate(self)
    }

    // MARK: - Bluetooth HR

    func centralManagerDidUpdateState(_ c: CBCentralManager) {
        if c.state == .poweredOn { scan() } else { hrStatus = "HR: Bluetooth mati"; delegate?.engineDidUpdate(self) }
    }

    private func scan() {
        hrStatus = "HR: mencari..."
        central.scanForPeripherals(withServices: [hrService], options: nil)
        delegate?.engineDidUpdate(self)
    }

    func centralManager(_ c: CBCentralManager, didDiscover p: CBPeripheral,
                        advertisementData: [String: Any], rssi RSSI: NSNumber) {
        hrPeripheral = p
        p.delegate = self
        c.stopScan()
        c.connect(p, options: nil)
        hrStatus = "HR: menyambung..."
        delegate?.engineDidUpdate(self)
    }

    func centralManager(_ c: CBCentralManager, didConnect p: CBPeripheral) {
        hrStatus = "HR: tersambung"
        p.discoverServices([hrService])
        delegate?.engineDidUpdate(self)
    }

    func centralManager(_ c: CBCentralManager, didFailToConnect p: CBPeripheral, error: Error?) {
        hrPeripheral = nil
        scan()
    }

    func centralManager(_ c: CBCentralManager, didDisconnectPeripheral p: CBPeripheral, error: Error?) {
        heartRate = 0
        hrPeripheral = nil
        scan()
    }

    func peripheral(_ p: CBPeripheral, didDiscoverServices error: Error?) {
        for s in p.services ?? [] { p.discoverCharacteristics([hrChar], for: s) }
    }

    func peripheral(_ p: CBPeripheral, didDiscoverCharacteristicsFor s: CBService, error: Error?) {
        for c in s.characteristics ?? [] where c.uuid == hrChar { p.setNotifyValue(true, for: c) }
    }

    func peripheral(_ p: CBPeripheral, didUpdateValueFor c: CBCharacteristic, error: Error?) {
        guard let data = c.value else { return }
        let b = [UInt8](data)
        guard b.count >= 2 else { return }
        if (b[0] & 0x01) == 0 {
            heartRate = Int(b[1])
        } else if b.count >= 3 {
            heartRate = Int(b[1]) | (Int(b[2]) << 8)
        }
        delegate?.engineDidUpdate(self)
    }

    // MARK: - GPX

    private func saveGPX() -> URL? {
        guard !points.isEmpty else { return nil }
        let iso = ISO8601DateFormatter()
        var s = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
        s += "<gpx version=\"1.1\" creator=\"Gowes\" xmlns=\"http://www.topografix.com/GPX/1/1\" "
        s += "xmlns:gpxtpx=\"http://www.garmin.com/xmlschemas/TrackPointExtension/v1\">\n"
        s += "<trk><name>Gowes</name><trkseg>\n"
        for (l, hr) in points {
            s += "<trkpt lat=\"\(l.coordinate.latitude)\" lon=\"\(l.coordinate.longitude)\">"
            s += "<ele>\(l.altitude)</ele><time>\(iso.string(from: l.timestamp))</time>"
            if hr > 0 {
                s += "<extensions><gpxtpx:TrackPointExtension><gpxtpx:hr>\(hr)</gpxtpx:hr></gpxtpx:TrackPointExtension></extensions>"
            }
            s += "</trkpt>\n"
        }
        s += "</trkseg></trk></gpx>\n"

        let df = DateFormatter()
        df.dateFormat = "yyyyMMdd-HHmmss"
        let dir = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let url = dir.appendingPathComponent("gowes-\(df.string(from: Date())).gpx")
        do {
            try s.write(to: url, atomically: true, encoding: .utf8)
            return url
        } catch {
            return nil
        }
    }

    static func format(_ t: TimeInterval) -> String {
        let n = Int(t)
        return String(format: "%d:%02d:%02d", n / 3600, (n % 3600) / 60, n % 60)
    }
}
